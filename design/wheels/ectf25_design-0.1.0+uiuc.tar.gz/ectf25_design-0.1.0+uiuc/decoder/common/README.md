# common

Crate that contains common structs and constants used by the Decoder, Encoder, and firmware-builder.